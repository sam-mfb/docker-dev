/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("e76de45fffbb6ab51b1d72269e16a7f53f775827")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2022-06-01 14:28:30 UTC")]
